import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parseAmount, validateExpense, filterExpenses, summarizeExpenses, toCSV} from '../src/ledger.js';
const rows=[
{id:'a',description:'Tea, cake',amountCents:1250,category:'Food',date:'2026-09-02'},
{id:'b',description:'Bus',amountCents:500,category:'Travel',date:'2026-09-03'},
{id:'c',description:'A "book"',amountCents:2000,category:'Other',date:'2026-08-31'}];
test('amount conversion uses integer cents',()=>{assert.equal(parseAmount('12.50'),1250);assert.equal(parseAmount('0.01'),1);assert.equal(parseAmount(' 10 '),1000);assert.equal(parseAmount('12.3'),1230);});
for(const invalid of ['','0','-1','NaN','Infinity','1e2','1.234','12usd']) test('reject amount '+JSON.stringify(invalid),()=>assert.throws(()=>parseAmount(invalid)));
test('validate and normalize expense',()=>assert.deepEqual(validateExpense({description:' Tea ',amount:'12.50',category:'Food',date:'2026-09-02'}),{description:'Tea',amountCents:1250,category:'Food',date:'2026-09-02'}));
for(const update of [{description:' '},{amount:'-2'},{category:'Invalid'},{date:'2026-02-30'},{date:'bad'}]) test('invalid fields '+JSON.stringify(update),()=>assert.throws(()=>validateExpense({description:'Tea',amount:'12.50',category:'Food',date:'2026-09-02',...update})));
test('search is case insensitive and trimmed',()=>assert.deepEqual(filterExpenses(rows,{query:'  BUS '}),[rows[1]]));
test('filters combine category and month',()=>assert.deepEqual(filterExpenses(rows,{category:'Food',month:'2026-09'}),[rows[0]]));
test('all filters preserve original input',()=>{const before=JSON.stringify(rows);assert.deepEqual(filterExpenses(rows,{}),rows);filterExpenses(rows,{query:'tea'});assert.equal(JSON.stringify(rows),before);});
test('empty summary',()=>assert.deepEqual(summarizeExpenses([]),{totalCents:0,count:0,byCategory:{}}));
test('summary uses exact cents',()=>assert.deepEqual(summarizeExpenses(rows),{totalCents:3750,count:3,byCategory:{Food:1250,Travel:500,Other:2000}}));
test('csv has header and escapes comma and quotes',()=>{const csv=toCSV(rows);assert.ok(csv.startsWith('Date,Description,Category,Amount\r\n'));assert.ok(csv.includes('2026-09-02,"Tea, cake",Food,12.50'));assert.ok(csv.includes('2026-08-31,"A ""book""",Other,20.00'));});
test('csv guards spreadsheet formula injection',()=>{const csv=toCSV([{...rows[0],description:'=1+1'}]);assert.ok(csv.includes("'=1+1"));});
test('html includes accessible required UI hooks',()=>{const html=readFileSync('index.html','utf8');for(const id of ['expense-form','description','amount','category','date','search','category-filter','month-filter','expense-list','total','count','export-csv','form-error'])assert.match(html,new RegExp('id=["\']'+id+'["\']'));assert.match(html,/type=["']module["']/);});
