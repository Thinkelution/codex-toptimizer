# Pocket Ledger starter
Build the app described in the supplied task prompt. No dependencies are needed.
Run `npm test` for the fixed acceptance tests and `npm start` for a local preview.
The test suite defines the public pure-function contract; do not edit package.json or test/.
